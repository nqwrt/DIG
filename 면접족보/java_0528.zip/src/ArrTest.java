import java.util.Random;
import java.util.Scanner;

public class ArrTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[][] arrTwo = {
				   {11, 22, 33},
				   {44, 55, 66}, 
				   {77, 88, 99}
				};
		
		for(int i =0; i < arrTwo.length;i++) {
			for(int j =0; j < arrTwo[i].length;j++) {
				System.out.print(arrTwo[i][j]+ "\t");
			}
			System.out.println();
		}
		
		int[] arr = new int[10];
		
		Random random = new Random();
		
		for(int i =0;i<arr.length;i++){
			arr[i] = random.nextInt(100) + 1;
			System.out.println(arr[i]);
		}
		
	    int max = ArrSortMax.getMaxValue(arr);
	    System.out.println(max);
	    
	    //=========================================
	    System.out.println("=======================");
	    int[] arr2 = ArrSortMax.getSortDESC(arr);
	    
	    for(int num : arr2)
	    	System.out.println(num);
		
	   //==============================================
	    Rectangle[] arrRec = new Rectangle[3];
	    
		for(int i =0; i< arrRec.length; i++){
			
			Scanner scanner = new Scanner(System.in);
			System.out.println("���ڵΰ��� ��������");
			arrRec[i] = new Rectangle(scanner.nextInt(), scanner.nextInt());			
		}
	    
		Rectangle maxRec = Rectangle.getMaxRec(arrRec);	
		System.out.println(maxRec.getArea());
		
		
		System.out.println("===================");
		
		Rectangle[] arrRec2 = Rectangle.getSortRec(arrRec);
		
		for(Rectangle rec : arrRec2 )
			System.out.println(rec.getArea());
		
		
	}

}
